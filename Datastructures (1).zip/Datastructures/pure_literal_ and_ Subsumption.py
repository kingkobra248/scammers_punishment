def Simplify(F, l):
    stack = []
    clauseCount = 0
    varCount = 0
    threeClauseCount = 0
    n = F['numVars']
    for i in range(1, F['numClauses'] + 1):
        clause = F['clauses'][i]
        if clause[0] == -1:
            continue
        clauseCount += 1
        if l in clause:
            clause[0] = -1
            stack.append((i, l))
            clauseCount -= 1
            if clauseCount == 0:
                return True
        elif -l in clause:
            if clause[0] > 1:
                clause[0] -= 1
                clause.remove(-l)
            else:
                clause[0] = -1
            if clause[0] == 0:
                return False
            else:
                stack.append((i, -l))
        elif clause[0] == 2:
            threeClauseCount -= 1
        varCount = max(varCount, abs(l))
    F['clauseCount'] = clauseCount
    F['varCount'] = varCount
    F['threeClauseCount'] = threeClauseCount
    return "Not Found"


def PureLiteral(F):
    # Initialize a list of literals that appear in F
    literals = list(F['literalOccurrences'].keys())

    # Iterate over each literal in the list
    for l in literals:
        # If the literal only appears with a positive polarity, set it to True
        if (l, 1) in F['literalOccurrences'] and (l, -1) not in F['literalOccurrences']:
            # Create a copy of F and simplify it using the pure literal rule
            F_copy = copy.deepcopy(F)
            for i in range(F_copy['clauseCount']):
                if l in F_copy['clauses'][i]:
                    F_copy['clauses'][i] = [lit for lit in F_copy['clauses'][i] if lit != l]
            del F_copy['literalOccurrences'][l]
            result = Simplify(F_copy, 0)

            # If the simplified formula is satisfiable, return True
            if result == True:
                return True
        # If the literal only appears with a negative polarity, set its negation to True
        elif (l, -1) in F['literalOccurrences'] and (l, 1) not in F['literalOccurrences']:
            # Create a copy of F and simplify it using the pure literal rule
            F_copy = copy.deepcopy(F)
            for i in range(F_copy['clauseCount']):
                if -l in F_copy['clauses'][i]:
                    F_copy['clauses'][i] = [lit for lit in F_copy['clauses'][i] if lit != -l]
            del F_copy['literalOccurrences'][-l]
            result = Simplify(F_copy, 0)

            # If the simplified formula is satisfiable, return True
            if result == True:
                return True

    # If no pure literal can be found, return False
    return False


def Subsumption(F):
    for i in range(F['clauseCount']):
        clause_i = F['clauses'][i]
        for j in range(F['clauseCount']):
            if i == j:
                continue
            clause_j = F['clauses'][j]
            if set(clause_i).issubset(set(clause_j)):
                F['clauses'].remove(clause_j)
                F['clauseCount'] -= 1
                if i > j:
                    i -= 1
                break
    if F['clauseCount'] == 0:
        return True
    return False



F = {'numVars': 3, 'numClauses': 3, 'clauses': [[2, 1, -3], [2, -1, 3], [2, -1, -3]], 'clauseCount': 3, 'varCount': 3, 'threeClauseCount': 3, 'literalOccurrences': {1: [(1, 2)], 2: [(1, 3), (2, 1)], 3: [(1, 1), (2, 3)]}}

result = PureLiteral(F)
if result == True:
    print("Satisfiable using Pure Literal")
else:
    print("Not satisfiable using Pure Literal")

result = Subsumption(F)
if result == True:
    print("Satisfiable using Subsumption")
else:
    print("Not satisfiable using Subsumption")
