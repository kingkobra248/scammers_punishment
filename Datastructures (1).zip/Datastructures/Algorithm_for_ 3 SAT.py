

def sat3(phi):
    """
    Implementation of the 3-SAT algorithm.
    Input: phi, a formula in 3-CNF over n variables with m clauses.
    Output: True if phi is satisfiable, False otherwise.
    """

    # If phi is empty, return True.
    if not phi:
        return True

    # Repeat while possible.
    while True:

        # If there is a variable that occurs only positively (negatively),
        # assign this literal true (i.e. call simplify function on this literal).
        simplified = False
        for clause in phi:
            for literal in clause:
                negation = -literal
                if negation not in clause:
                    phi = simplify(phi, literal)
                    simplified = True
                    break
            if simplified:
                break

        # If the formula contains single literal clause {l},
        # assign this literal true.
        for clause in phi:
            if len(clause) == 1:
                literal = clause[0]
                phi = simplify(phi, literal)
                break

        # Subsume all 3 clauses (i.e. call subsumption function).
        phi = subsume(phi)

        # If empty clause is discovered, return False.
        if [] in phi:
            return False

        # Pick smallest clause (shortest list) C so that phi = C ∧ phi'.
        C = min(phi, key=len)
        phi_prime = [clause for clause in phi if clause != C]

        # If 3-SAT(phi' | l1 = True) is True, return True.
        if sat3(update(phi_prime, C[0], True)):
            return True

        # If 3-SAT(phi' | l1 = False, l2 = True) is True, return True.
        if sat3(update(phi_prime, C[0], False, C[1], True)):
            return True

        # If C has 3 literals and 3-SAT(phi' | l1 = False, l2 = False, l3 = True) is True, return True.
        if len(C) == 3 and sat3(update(phi_prime, C[0], False, C[1], False, C[2], True)):
            return True

        # If none of the above worked, return False.
        return False


def simplify(phi, literal):
    """
    Simplifies the formula phi by assigning the literal to True and removing clauses containing it or its negation.
    """
    phi_prime = []
    for clause in phi:
        if literal in clause:
            continue
        elif -literal in clause:
            clause.remove(-literal)
            phi_prime.append(clause)
        else:
            phi_prime.append(clause)
    return phi_prime


def subsume(phi):
    """
    Subsumes all 3 clauses in the formula phi.
    """
    phi_prime = []
    for i, clause1 in enumerate(phi):
        for j, clause2 in enumerate(phi):
            if i != j and set(clause1).issubset(set(clause2)):
                break
        else:
            phi_prime.append(clause1)
    return phi_prime




def update(phi, *args):
    """
    Updates the formula phi by assigning truth values to variables.
    """
    phi_prime = []
    for clause in phi:
        new_clause = clause.copy()
        for i in range(0, len(args), 2):
            literal, value = args[i], args[i+1]
            new_clause = [l for l in new_clause if l != literal]
            if value:
                new_clause.append(literal)
            else:
                new_clause.append(-literal)
        phi_prime.append(new_clause)
    return phi_prime

phi = [[1, -2, 3], [-1, 2, -3]]
print(sat3(phi))
