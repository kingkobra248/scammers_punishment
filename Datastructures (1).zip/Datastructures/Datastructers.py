class SATSolver:
    def __init__(self, clauses, variables):
        self.CL = clauses
        self.V = variables
        self.assigned_variables = set()
        self.assigned_variable_count = 0
        self.unassigned_variable_count = len(variables)
        self.counter_clauses = len(clauses)

    def choose_literal(self):
        # This is just an example of how to choose a literal
        # You can implement your own strategy
        for v in self.V:
            if v not in self.assigned_variables and -v not in self.assigned_variables:
                return v

    def assign_literal(self, l):
        self.assigned_variables.add(l)
        self.assigned_variable_count += 1
        self.unassigned_variable_count -= 1
        print(f"Assigned literal: {l}")

    def undo_assignment(self, assigned_literals):
        for l in assigned_literals:
            self.assigned_variables.discard(l)
            self.assigned_variable_count -= 1
            self.unassigned_variable_count += 1

    def unit_propagation(self):
        stack = []
        while True:
            # Find all unit clauses
            unit_clauses = [c for c in self.CL if len(c) == 2 and c[0] not in self.assigned_variables]

            # If there are no unit clauses, we're done
            if len(unit_clauses) == 0:
                break

            # Assign the literal of the unit clause
            l = unit_clauses[0][0]
            stack.append(l)
            self.assign_literal(l)

            # Remove clauses that contain the literal and remove the negation of the literal from other clauses
            for clause in self.CL:
                if l in clause:
                    self.CL.remove(clause)
                    self.counter_clauses -= 1
                elif -l in clause:
                    clause.remove(-l)

        return stack

    def backtrack(self, assigned_literals):
        self.assigned_variables.difference_update(assigned_literals)
        self.assigned_variable_count -= len(assigned_literals)
        self.unassigned_variable_count += len(assigned_literals)
        self.undo_assignment(assigned_literals)

    def dpll(self, depth=0):
        # If all clauses are satisfied, return True
        if self.counter_clauses == 0:
            return True

        # If there is an empty clause, return False
        for clause in self.CL:
            if clause[0] == 0:
                return False

        # Choose unassigned variable and assign it
        l = self.choose_literal()
        self.assign_literal(l)

        # Perform unit propagation
        stack = self.unit_propagation()

        # If the formula is unsatisfiable, backtrack
        if stack is False:
            self.undo_assignment([])
            return False

        # Recursive call with reduced formula
        print(f"Depth: {depth}, Assigned literal: {l}")
        if self.dpll(depth + 1) is True:
            return True

        # Backtrack if recursive call returns False
        self.undo_assignment(stack)
        self.assign_literal(-l)
        return self.dpll(depth + 1)


# Test the algorithm with example clauses and variables
clauses = [[1, 2], [1, -2], [-1, 2], [-1, -2], [3, 4], [3, -4], [-3, 4], [-3, -4]]
variables = [1, 2, 3, 4]

solver = SATSolver(clauses, variables)
result = solver.dpll()

print(f"\nFinal result: {result}")
