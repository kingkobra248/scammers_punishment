from typing import List, Tuple

# Definition of the input formula
F = [[1, 2], [1, -2, -3], [-1, 3], [-1, -3]]

# Number of variables and clauses
n_vars = 3
n_clauses = 4

# Occurrence lists: for each variable, a list of the clauses that contain it
pos_occur = {i: [] for i in range(1, n_vars+1)}
neg_occur = {i: [] for i in range(1, n_vars+1)}

for i, clause in enumerate(F):
    for lit in clause:
        if lit > 0:
            pos_occur[lit].append(i+1)
        else:
            neg_occur[-lit].append(i+1)

# 2-clause list: for each clause, the number of literals that appear in it
two_clauses = [i for i, clause in enumerate(F) if len(clause) == 2]

def simplify(F: List[List[int]]) -> Tuple[List[List[int]], bool]:
    """Simplifies the input formula F by removing all satisfied clauses and literals."""
    # Boolean variable to track if any simplification was made
    simplification_made = False

    # Remove all clauses that are satisfied
    F = [clause for clause in F if not is_satisfied(clause)]

    # Remove all literals that appear only in a single clause
    for lit in range(1, n_vars+1):
        if len(pos_occur[lit]) == 1 and len(neg_occur[lit]) == 0:
            clause_idx = pos_occur[lit][0] - 1
            F = remove_literal(F, clause_idx, lit)
            simplification_made = True
        elif len(neg_occur[lit]) == 1 and len(pos_occur[lit]) == 0:
            clause_idx = neg_occur[lit][0] - 1
            F = remove_literal(F, clause_idx, -lit)
            simplification_made = True

    return F, simplification_made

def remove_literal(F: List[List[int]], clause_idx: int, lit: int) -> List[List[int]]:
    """Removes the literal from the specified clause, and simplifies the formula."""
    clause = F[clause_idx]
    clause.remove(lit)

    # Update occurrence lists
    if lit > 0:
        pos_occur[lit].remove(clause_idx + 1)
    else:
        neg_occur[-lit].remove(clause_idx + 1)

    # Simplify formula
    F, _ = simplify(F)

    return F

def is_satisfied(clause: List[int]) -> bool:
    """Returns True if the clause is satisfied (i.e., contains a literal that evaluates to True)."""
    for lit in clause:
        if lit > 0:
            if model[lit-1]:
                return True
        else:
            if not model[-lit-1]:
                return True
    return False

def solve_3sat(F: List[List[int]], model: List[bool]) -> Tuple[List[bool], bool]:
    """Solves the 3-SAT problem for the input formula F, using the specified initial model."""
    # Simplify formula
    F, simplification_made = simplify(F)
    while simplification_made:
        # If the formula has been simplified to the empty list, return the current model
        if len(F) == 0:
            return model, True

        # Choose an unassigned variable and set it to True
        unassigned_vars = [i for i, val in enumerate(model) if val is None]
        var = unassigned_vars[0] + 1
        model[var-1] = True

        # Try to recursively solve the simplified formula
        res, is_sat = solve_3sat(F, model)
        if is_sat:
            return res, True

        # If the recursive call did not return a satisfying assignment, set the variable to False
        model[var-1] = False

        # Try to recursively solve the simplified formula with the variable set to False
        res, is_sat = solve_3sat(F, model)
        if is_sat:
            return res, True

        # If neither the True nor False setting of the variable led to a satisfying assignment, backtrack
        model[var-1] = None
        F, _ = simplify(F)

    # If all simplifications have been made and the formula is not empty, return the current model and False
    return model, False

n_vars = 3
model = [None] * n_vars
result, is_sat = solve_3sat(F, model)
if is_sat:
    print("Satisfying assignment found:", result)
else:
    print("Formula is satisfiable")


